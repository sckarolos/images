import { Directive } from '@angular/core';

@Directive({
  selector: '[appCardBody]'
})
export class CardBodyDirective {
}