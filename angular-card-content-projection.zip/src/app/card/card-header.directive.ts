import { Directive } from '@angular/core';

@Directive({
  selector: '[appCardHeader]'
})
export class CardHeaderDirective {
}