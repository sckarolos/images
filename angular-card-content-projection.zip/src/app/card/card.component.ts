import { Component, OnInit, Input, ContentChild } from '@angular/core';
import { CardHeaderDirective } from './card-header.directive';
import { CardBodyDirective } from './card-body.directive';
import { CardFooterDirective } from './card-footer.directive';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  @ContentChild(CardHeaderDirective) header?: CardHeaderDirective;
  @ContentChild(CardBodyDirective) body?: CardBodyDirective;
  @ContentChild(CardFooterDirective) footer?: CardFooterDirective;

  constructor() { }

  ngOnInit() {
  }

}