import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { CardComponent } from './card/card.component';
import { CardHeaderDirective } from './card/card-header.directive';
import { CardBodyDirective } from './card/card-body.directive';
import { CardFooterDirective } from './card/card-footer.directive';

@NgModule({
  imports:      [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, HelloComponent, CardComponent, CardHeaderDirective, CardBodyDirective, CardFooterDirective ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
